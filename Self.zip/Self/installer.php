import os

# install tools for self
os.system("python3 -m pip install -r requirements.txt")

# need to edit
# line 117  self.py
# line 12  helper.py
